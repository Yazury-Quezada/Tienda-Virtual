<?php
const BASE_URL = "http://localhost/shop/";
const HOST = "localhost";
const USER = "root";
const PASS = "";
const DB = "shop";
const CHARSET = "charset=utf8";
const TITLE = "SHOP";
const MONEDA = "USD";
const CLIENT_ID = "AYeHa9ejHgUryrT6aQqbKuxNrBp2XxNYWNi4vnJjODlG1V9dza6GYTDX1iKjYBB99ZUCzTflPeHZLmxq";
?>
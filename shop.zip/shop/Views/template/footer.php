<footer class="footer spad">
  <div class="container">
    <div class="row">
      <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="footer__about">
          <div class="footer__about__logo">
            <a href="<?php echo BASE_URL; ?>"><img src="<?php echo BASE_URL; ?>public/img/logo.png" alt="" width="50"></a>
          </div>
          <ul>
            <li>Ciudad: <?php echo $data['negocio']['direccion']; ?></li>
            <li>Telefono: <?php echo $data['negocio']['telefono']; ?></li>
            <!-- Utilizar directamente la variable PHP para el enlace de correo electrónico -->
            <li>Correo Electronico: <a href="mailto:<?php echo $data['negocio']['correo']; ?>" style="color: #663399;"><?php echo $data['negocio']['correo']; ?></a></li>
          </ul>
        </div>
      </div>
    </div>
    
    <div class="row">
      <div class="col-lg-12">
        <div class="footer__copyright">
          <div class="footer__copyright__text">
            <p>
              Rtgifts &copy;<script>
                document.write(new Date().getFullYear());
              </script> Los derechos reservados </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</footer>
<!-- Footer Section End -->

<!-- Js Plugins -->
<script src="<?php echo BASE_URL; ?>public/js/jquery-3.3.1.min.js"></script>
<script src="<?php echo BASE_URL; ?>public/js/bootstrap.min.js"></script>
<script src="<?php echo BASE_URL; ?>public/js/jquery.nice-select.min.js"></script>
<script src="<?php echo BASE_URL; ?>public/js/jquery-ui.min.js"></script>
<script src="<?php echo BASE_URL; ?>public/js/jquery.slicknav.js"></script>
<script src="<?php echo BASE_URL; ?>public/js/mixitup.min.js"></script>
<script src="<?php echo BASE_URL; ?>public/js/owl.carousel.min.js"></script>
<script src="<?php echo BASE_URL; ?>public/js/main.js"></script>
<script type="text/javascript" src="<?php echo BASE_URL; ?>public/js/toastify-js.js"></script>
<script>
  const ruta = '<?php echo BASE_URL; ?>';
  function alerta(mensaje, type) {
  let color = type == 1 ? "#46cd93" : "#f24734";
  Toastify({
    text: mensaje,
    duration: 3000,
    close: true,
    gravity: "top", // `top` or `bottom`
    position: "right", // `left`, `center` or `right`
    stopOnFocus: true, // Prevents dismissing of toast on hover
    style: {
      background: color,
      borderRadius: "2rem",
      textTransform: "uppercase",
      fontSize: ".75rem",
    },
    offset: {
      x: "1.5rem", // horizontal axis - can be a number or a string indicating unity. eg: '2em'
      y: "1.5rem", // vertical axis - can be a number or a string indicating unity. eg: '2em'
    },
    onClick: function () {}, // Callback after click
  }).showToast();
}
</script>
<script src="<?php echo BASE_URL; ?>public/js/sweetalert2.all.min.js"></script>
